# Militant Monk App

This is the starting version of the Militant Monk Command Center web app.